#!/usr/bin/env python3


from . import ai
from django.shortcuts import render, HttpResponse

# Create your views here.


def homepage(request):

    return render(request, "home.html")


def teams(request):
    if request.method == "POST":
        value = request.POST["name_field"]
        return HttpResponse(ai.call(value))
