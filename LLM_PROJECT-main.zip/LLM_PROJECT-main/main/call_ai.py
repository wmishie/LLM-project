#!/usr/bin/env python3

from ai import call

ingredients = input("enter your list of ingridents>>  ")

print(call(ingredients))
