#!/usr/bin/env python3


from langchain.prompts import PromptTemplate
from huggingface_hub import InferenceClient
import json

llm = InferenceClient(model="tiiuae/falcon-7b-instruct",
                      timeout=120,
                      token="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")


ingred = []
ingred_template = """
I am providing you with a list of ingredients, give me best recipe you can think of,
if the ingredients are not specific, provide the closest recipe, and advice on extra ingredients the user can add, give the user quantities of the ingredients to use, also mention the name of the dish you have recommended,
{ingred}
"""

prompt = PromptTemplate(
    input_variables=["ingred"],
    template=ingred_template,

)


def llm_call(inference_client, prompt):
    response = inference_client.post(
        json={"inputs": prompt,
              "parameters": {"max_new_tokens": 200},
              "task": "text-generation",
              },
    )
    return json.loads(response.decode())[0]["generated_text"]





def call(stuff):
    ingred.append(stuff)
    return llm_call(llm, prompt.format(ingred=ingred))
